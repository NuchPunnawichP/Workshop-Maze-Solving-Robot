/*
 * CPPmain.h
 *
 *  Created on: Jan 15, 2025
 *      Author: Pannawit
 */

#ifndef CPPMAIN_H_
#define CPPMAIN_H_

#include "main.h"
#ifdef __cplusplus
extern "C" {
#endif

void setup();
void loop();

void Drive_motor(uint8_t ml, uint8_t mr);

void gpio_init();

#ifdef __cplusplus
}
#endif

#endif /* CPPMAIN_H_ */
